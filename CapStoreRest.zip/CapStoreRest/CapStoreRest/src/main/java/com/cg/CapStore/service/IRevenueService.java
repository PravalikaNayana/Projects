package com.cg.CapStore.service;

import java.util.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.CapStore.model.CapStoreTransaction;

public interface IRevenueService {

	public List<CapStoreTransaction> getRevenue(Date fromDate,Date tillDate);

	public double getAmountByTransId(Integer transactionId);

	public List<CapStoreTransaction> printAll();
}
