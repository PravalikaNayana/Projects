package com.cg.CapStore.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CapStore.model.CapStoreTransaction;
import com.cg.CapStore.service.IPaymentService;
import com.cg.CapStore.service.IRevenueService;

@RestController
@RequestMapping("/api/v1")
public class RevenueController {

	@Autowired
	private IRevenueService revenueService;
	
	@Autowired
	private IPaymentService paymentService;
	
	@RequestMapping("/displayRevenue1")
	public ResponseEntity<List<CapStoreTransaction>> printAll()
	{
		List<CapStoreTransaction> transactions=revenueService.printAll();
		//System.out.println(revenue);
		return new ResponseEntity<List<CapStoreTransaction>>(transactions,HttpStatus.OK);
		
	}
	
	@RequestMapping("/displayRevenue")
	public ResponseEntity<List<CapStoreTransaction>> getRevenue(
			@RequestParam("fromDate")Date fromDate,
			@RequestParam("tillDate")Date tillDate)
	{
		List<CapStoreTransaction> transactions=revenueService.getRevenue(fromDate,tillDate);
		//System.out.println(revenue);
		return new ResponseEntity<List<CapStoreTransaction>>(transactions,HttpStatus.OK);
		
	}
	
	@RequestMapping("/confirmPayment/{transactionId}")
	public void confirmPay(@PathVariable("transactionId") Integer transactionId,
			HttpSession session)
	{
		int customerId=(int) session.getAttribute("custId");
		double amount=revenueService.getAmountByTransId(transactionId);
		paymentService.deductAmount(customerId,amount);
		
	}
}
