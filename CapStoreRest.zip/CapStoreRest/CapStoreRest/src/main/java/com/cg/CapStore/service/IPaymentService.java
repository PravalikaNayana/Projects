package com.cg.CapStore.service;

public interface IPaymentService {

	//public void updateBalance();

	public void deductAmount(Integer customerId,double amount);
}
