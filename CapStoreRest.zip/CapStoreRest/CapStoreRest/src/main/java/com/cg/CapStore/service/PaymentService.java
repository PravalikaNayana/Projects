package com.cg.CapStore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.CapStore.dao.IPaymentDao;

@Service("paymentService")
public class PaymentService implements IPaymentService{

	@Autowired
	private IPaymentDao paymentDao;

	@Override
	public void deductAmount(Integer customerId, double amount) {
		
		paymentDao.deductAmount(customerId,amount);
	}

	
}
