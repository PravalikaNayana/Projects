package com.cg.CapStore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.CapStore.model.BankAccount;
import com.cg.CapStore.model.CapStoreTransaction;

@Repository("paymentDao")
public interface IPaymentDao extends JpaRepository<BankAccount, Integer>{

	@Query("update BankAccount set amount=:amount where customerId=:customerId")
	public void deductAmount(Integer customerId, double amount);

	
}
