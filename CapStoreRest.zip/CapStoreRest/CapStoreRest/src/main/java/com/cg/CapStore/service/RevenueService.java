package com.cg.CapStore.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.CapStore.dao.IPaymentDao;
import com.cg.CapStore.dao.IRevenueDao;
import com.cg.CapStore.model.CapStoreTransaction;

@Service("revenueService")
@Transactional
public class RevenueService implements IRevenueService{

	@Autowired
	private IRevenueDao revenueDao;
	
	@Override
	public List<CapStoreTransaction> getRevenue(Date fromDate,Date tillDate) {
		
		List<CapStoreTransaction> transactions=revenueDao.findBetweenDates(fromDate,tillDate);
		 /*System.out.println(transactions);*/
		return transactions;

	}
	

	@Override
	public double getAmountByTransId(Integer transactionId) {
		
		return revenueDao.getAmountByTransId(transactionId);
	}


	@Override
	public List<CapStoreTransaction> printAll() {
		
		return revenueDao.printAll();
	}

	
	
}
