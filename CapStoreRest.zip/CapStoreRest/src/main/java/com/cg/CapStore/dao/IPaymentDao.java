package com.cg.CapStore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.CapStore.model.CapStoreTransaction;

@Repository("paymentDao")
public interface IPaymentDao extends JpaRepository<CapStoreTransaction, Integer>{

}
