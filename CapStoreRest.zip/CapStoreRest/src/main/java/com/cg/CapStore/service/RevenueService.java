package com.cg.CapStore.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.CapStore.dao.IRevenueDao;
import com.cg.CapStore.model.CapStoreTransaction;

@Service("revenueService")
@Transactional
public class RevenueService implements IRevenueService{

	@Autowired
	private IRevenueDao revenueDao;
	
	@Override
	public List<CapStoreTransaction> getRevenue() {
		
		List<CapStoreTransaction> transactions=revenueDao.findAll();
		
		//return new ResponseEntity<List<CapStoreTransaction>>(transactions,HttpStatus.OK);
		
		
		//return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK); 
		 
		return transactions;

	}

	
}
