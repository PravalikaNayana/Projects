package com.cg.CapStore.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CapStore.service.IRevenueService;

@RestController
@RequestMapping("/api/v1")
public class RevenueController {

	@Autowired
	private IRevenueService revenueService;
	
	@RequestMapping("/displayRevenue")
	public void getRevenue(@RequestParam("fromDate") Date fromDate,
			@RequestParam("tillDate") Date tillDate)
	{
		revenueService.getRevenue(fromDate,tillDate);
	}
	
}
