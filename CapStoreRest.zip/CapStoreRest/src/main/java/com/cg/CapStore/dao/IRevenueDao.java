package com.cg.CapStore.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.CapStore.model.CapStoreTransaction;

@Repository("revenueDao")
public interface IRevenueDao extends JpaRepository<CapStoreTransaction, Integer>{

	List<CapStoreTransaction> findBetweenDates(Date fromDate, Date tillDate);
	
}
