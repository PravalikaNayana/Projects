import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	private HotelBookingPage page = new HotelBookingPage();
	@Given("^The Customer is on the Login Page$")
	public void the_Customer_is_on_the_Login_Page() throws Exception {
		page.goTo();
		
	}

	@When("^He enters the Valid UserName$")
	public void he_enters_the_Valid_UserName() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setuserName("Capgemini");
	}

	@When("^He enters the Valid Password$")
	public void he_enters_the_Valid_Password() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setuserPwd("capg1234");
	}

	@When("^He clicks Login$")
	public void he_clicks_Login() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.clickNext();
	}

	@When("^He is directed to Hotel Booking Page$")
	public void he_is_directed_to_Hotel_Booking_Page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.accept();
		page.goTo2();
	}

	@When("^check if the title is Hotel Booking$")
	public void check_if_the_title_is_Hotel_Booking() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(page.isAt2()); 
	}

	@When("^He enters the Valid First Name$")
	public void he_enters_the_Valid_First_Name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setFirstName("Syam");
	}

	@When("^He enters the Valid Last Name$")
	public void he_enters_the_Valid_Last_Name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setLastName("Kuamr");
	}

	@When("^He enters the Valid Email$")
	public void he_enters_the_Valid_Email() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setEmail("syam.puppala@capgemini.com");
	}

	@When("^He enters the Valid Contact No$")
	public void he_enters_the_Valid_Contact_No() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setPhone("8331811624");
	}

	@When("^He selects the Number of people staying in hotel$")
	public void he_selects_the_Number_of_people_staying_in_hotel() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.selectNoOfPeopleAttending();
	}

	@When("^He enters the  Valid Address$")
	public void he_enters_the_Valid_Address() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setAddress1("chinagonnuru, gudlavalleru.");
	}

	@When("^He selects the City$")
	public void he_selects_the_City() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.selectCity();
	}

	@When("^He selects the State$")
	public void he_selects_the_State() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.selectState();
	}

	@When("^He enters the Card Holder Name$")
	public void he_enters_the_Card_Holder_Name() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setCardholderName("SYAM KUAMR");
	}

	@When("^He enters the Debit card number$")
	public void he_enters_the_Debit_card_number() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   page.setDebit("1234567890129876");
	}
	@When("^He enters the Valid CVV$")
	public void he_enters_the_Valid_CVV() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
	   page.settxtCvv("123");
	}
	@When("^He enters the Card expiration month$")
	public void he_enters_the_Card_expiration_month() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setMonth("2");
	}

	@When("^He enters the Card expiration year$")
	public void he_enters_the_Card_expiration_year() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.setYear("2020");
	}

	@When("^He clicks on Confirm Booking$")
	public void he_clicks_on_Confirm_Booking() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.clickMakePayment();
	}

	@Then("^He is directed to Hotel Room Booking successfully done$")
	public void he_is_directed_to_Hotel_Room_Booking_successfully_done() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		page.goTo3();
		page.close();
	}
}
