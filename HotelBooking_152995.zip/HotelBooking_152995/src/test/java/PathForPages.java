
public class PathForPages {

	//please change the urls
	
	//login.html url
	static String url = "file:///D:/SyamKumar_BDD/HotelBooking_152995/src/main/webapp/login.html";
	static String title = "login.html";
	
	//hotelbooking.html url
	static String url2 = "file:///D:/SyamKumar_BDD/HotelBooking_152995/src/main/webapp/hotelbooking.html";
	static String title2 = "Hotel Booking";
	
	//success.html url
	static String url3 = "file:///D:/SyamKumar_BDD/HotelBooking_152995/src/main/webapp/success.html";
	
	public void goTo() {
		Browser.goTo(url);
	}
	
	public void goTo2() {
		Browser.goTo(url2);
	}
	public void goTo3() {
		Browser.goTo(url3);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}
	
	public boolean isAt2() {
		System.out.println(Browser.title());
		return Browser.title().equals(title2);
	}


}


