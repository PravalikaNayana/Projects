import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingPage extends PathForPages {

	public HotelBookingPage() {
		PageFactory.initElements(Browser.driver,this);
	}
	WebElement element;
	Select select;
	@FindBy(how=How.ID,id="userName")
	private WebElement userName;
	
	@FindBy(how=How.ID,id="userPwd")
	private WebElement userPwd;
	
	@FindBy(how=How.ID,id="txtFirstName")
	private WebElement firstName;

	@FindBy(how=How.ID,id="txtLastName")
	private WebElement lastName;
	
	@FindBy(how=How.ID,id="txtEmail")
	private WebElement email;
	
	@FindBy(how=How.ID,id="txtPhone")
	private WebElement phone;
	
	@FindBy(how=How.ID,id="txtAddress1")
	private WebElement address1;
	
	@FindBy(how=How.ID,id="txtCardholderName")
	private WebElement cardholderName;
	
	@FindBy(how=How.ID,id="txtDebit")
	private WebElement debit;
	
	@FindBy(how=How.ID,id="txtCvv")
	private WebElement cvv;
	
	@FindBy(how=How.ID,id="txtMonth")
	private WebElement month;
	
	@FindBy(how=How.ID,id="txtYear")
	private WebElement year;
	
	public String getuserName() {
		return userName.getText();
	}

	public void setuserName(String userName) {
		this.userName.sendKeys(userName);; 
	}
	public String getuserPwd() {
		return userPwd.getText();
	}

	public void setuserPwd(String userPwd) {
		this.userPwd.sendKeys(userPwd);; 
	}

	public String getFirstName() {
		return firstName.getText();
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);; 
	}

	public String getLastName() {
		return lastName.getText();
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);;  
	}

	public String getEmail() {
		return email.getText();
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);; 
	}

	public String getPhone() {
		return phone.getText();
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);; 
	}

	public String getAddress1() {
		return address1.getText();
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);;
	}

	

	public String getCardholderName() {
		return cardholderName.getText();
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName.sendKeys(cardholderName);;
	}

	public String getDebit() {
		return debit.getText();
	}

	public void setDebit(String debit) {
		this.debit.sendKeys(debit);; 
	}

	public String getCvv() {
		return cvv.getText();
	}

	public void settxtCvv(String cvv) {
		this.cvv.sendKeys(cvv);; 
	}
	public String getMonth() {
		return month.getText();
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);; 
	}

	public String getYear() {
		return year.getText();
	}

	public void setYear(String year) {
		this.year.sendKeys(year);; 
	}
	
	public void selectNoOfPeopleAttending() {
		// TODO Auto-generated method stub
		element=Browser.driver.findElement(By.name("persons"));
		select = new Select(element);
		select.selectByVisibleText("3");
	}
	
	public void selectCity() {
		// TODO Auto-generated method stub
		WebElement element=Browser.driver.findElement(By.name("city"));
		Select select = new Select(element);
		select.selectByVisibleText("Hyderabad");
	}

	public void selectState() {
		// TODO Auto-generated method stub
		WebElement element=Browser.driver.findElement(By.name("state"));
		Select select = new Select(element);
		select.selectByVisibleText("Telangana");
	}

	

	public void clickNext() {
		// TODO Auto-generated method stub
		Browser.driver.findElement(By.id("btn")).click();
	}

	public void clickMakePayment() {
		// TODO Auto-generated method stub
		Browser.driver.findElement(By.id("btnPayment")).click();
	}

	public void success() {
		// TODO Auto-generated method stub
		System.out.println("Success");

	}
	public void accept()
	{
	Alert simpleAlert = Browser.driver.switchTo().alert();  
	String alertText = simpleAlert.getText();          
	simpleAlert.accept();
	}

	public void close() {
		// TODO Auto-generated method stub
		Browser.close();
	}
}
