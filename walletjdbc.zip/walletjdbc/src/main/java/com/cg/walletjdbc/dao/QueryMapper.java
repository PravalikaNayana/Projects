package com.cg.walletjdbc.dao;


public interface QueryMapper {

	public static final String INSERT_QUERY="INSERT INTO Customer VALUES(customerId_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String CUSTOMERID_QUERY_SEQUENCE="SELECT customerId_sequence.CURRVAL FROM DUAL";

	public static final String SELECT_FROM_WALLET="SELECT accountno_sequence.CURRVAL FROM DUAL";
	//public static final String 
	
	
}
