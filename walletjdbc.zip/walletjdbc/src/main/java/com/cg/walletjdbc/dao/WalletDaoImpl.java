package com.cg.walletjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.bean.Transactions;
import com.cg.walletjdbc.exception.WalletException;
import com.cg.walletjdbc.util.DBConnection;

public class WalletDaoImpl implements WalletDao{

	Logger logger=Logger.getRootLogger();

	public WalletDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	@Override
	public int createAccount(Customer customer) throws WalletException {

		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
int customerId=0;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,customer.getName());
			preparedStatement.setInt(2,customer.getAge());
			preparedStatement.setString(3,customer.getGender());
			preparedStatement.setString(4,customer.getPhone());
			preparedStatement.setString(5,customer.getAddress());

					
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMERID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				customerId=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return customerId;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}

	@Override
	public int assignAccount(String type) throws WalletException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double showBalance(int accno) throws WalletException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double deposit(int accno, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int withdraw(int accno, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int fundTransfer(int faccno, int taccno, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Transactions printTransactions(String accno) throws WalletException {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
