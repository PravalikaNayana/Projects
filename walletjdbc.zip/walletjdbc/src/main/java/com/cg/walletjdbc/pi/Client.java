package com.cg.walletjdbc.pi;

import java.util.Scanner;

import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.bean.Transactions;
import com.cg.walletjdbc.bean.Wallet;
import com.cg.walletjdbc.dao.WalletDao;
import com.cg.walletjdbc.dao.WalletDaoImpl;
import com.cg.walletjdbc.exception.WalletException;
import com.cg.walletjdbc.service.WalletService;
import com.cg.walletjdbc.service.WalletServiceImpl;

public class Client {

		static Scanner scan=new Scanner(System.in);
		WalletService walletservice=new WalletServiceImpl();

		public static void main(String[] args) throws WalletException{

				Client c=new Client();

				while(true)
				{
					System.out.println("Welcome to XYZ Bank");
					System.out.println("1. Create Account:");
					System.out.println("2. Show Balance:");
					System.out.println("3. Deposit:");
					System.out.println("4. Withdraw:");
					System.out.println("5. Fund Transfer:");
					System.out.println("6. Print Transactions:");
					System.out.println("7. Exit!");
					String option=null;
					option=scan.nextLine();
					
					switch(option)
					{
					case "1":
						c.createAccount();
						break;
					case "2":
						c.showBalance();
						break;
					case "3":
						c.deposit();
						break;
					case "4":
						c.withdraw();
						break;
					case "5":
						c.fundTransfer();
						break;
					case "6":
						c.printTransactions();
						break;
					case "7":
						System.exit(0);
						break;
					default:
						System.out.println("Invalid option selected!");
						break;
						
					}
				}	
			}
			public void createAccount()
			{
				Customer customer=new Customer();
				System.out.println("Enter Customer name:");
				customer.setName(scan.nextLine());
				System.out.println("Enter customer age:");
				customer.setAge(Integer.parseInt(scan.nextLine()));
				System.out.println("Enter customer gender:");
				customer.setGender(scan.nextLine());
				System.out.println("Enter customer phone number");
				customer.setPhone(scan.nextLine());
				System.out.println("Enter address:");
				customer.setAddress(scan.nextLine());
		try {
			boolean result=walletservice.validateWallet(customer);
			if(result) {
				double initbalance=0;
				int ret=walletservice.createAccount(customer);
				System.out.println("Customer with id"+ret+"added successfully");
				System.out.println("Enter account type:");
				Wallet wallet=new Wallet();
				String type=scan.nextLine();
				wallet.setType(type);
				wallet.setBalance(initbalance);
				WalletDao walletdao=new WalletDaoImpl();
				int accno=walletdao.assignAccount(type);
				System.out.println("Your account number is:"+accno);
			}
		}
		catch(WalletException ex) {
			System.out.println();
			System.out.println("An error occurred"+ex.getMessage());
			System.out.println();
		}
			}
			
			public void showBalance() throws WalletException
			{
				try {
					System.out.println("Enter account  number:");
					int accno=Integer.parseInt(scan.nextLine());
					double balance=walletservice.showBalance(accno);
					System.out.println("Your account balance is:"+balance);
				}
				catch(WalletException ex)
				{
					System.out.println("Error!"+ex.getMessage());
				}
			}
			
			public void deposit()
			{
				try {
					System.out.println("Enter account number:");
					int accno=Integer.parseInt(scan.nextLine());
					System.out.println("Enter the amount:");
					double amount=Double.parseDouble(scan.nextLine());

					double result=walletservice.deposit(accno,amount);
					if(result!=-1)
					{
						System.out.println("Amount deposited successfully!");
					}
					else
					{
						System.err.println("Could not deposit amount.!");
					}
				}
				catch(Exception ex)
				{
					System.out.println(ex.getMessage());
				}
			}
			
			public void withdraw() {
				try {
					System.out.println("Enter account number:");
					int accno=Integer.parseInt(scan.nextLine());
					System.out.println("Enter the amount:");
					int amount=Integer.parseInt(scan.nextLine());

					double result=walletservice.withdraw(accno,amount);
					if(result!=0)
					{
						System.out.println("Amount withdrawn successfully!");
					}
					else
					{
						System.err.println("Could not withdraw amount.!");
					}
				}
				catch(Exception ex)
				{
					System.out.println(ex.getMessage());
				}
			}
			public void fundTransfer() {
				try {
					System.out.println("Enter from account :");
					int faccno=Integer.parseInt(scan.nextLine());
					System.out.println("Enter to account :");
					int taccno=Integer.parseInt(scan.nextLine());
					System.out.println("Enter the amount:");
					int amount=Integer.parseInt(scan.nextLine());

					double result=walletservice.fundTransfer(faccno,taccno,amount);
					if(result!=0)
					{
						System.out.println("Amount transferred successfully!");
					}
					else
					{
						System.err.println("Could not transfer amount.!");
					}
				}
				catch(Exception ex)
				{
					System.out.println(ex.getMessage());
				}
			}

			public void printTransactions()
			{
				try {
					System.out.println("Enter account number:");
					String accno=scan.nextLine();
					Transactions transaction=walletservice.printTransactions(accno);
					System.out.println(transaction);
				}
				catch(Exception ex)
				{
					System.out.println(ex.getMessage());
				}
			}
		


}
