package com.cg.walletjdbc.bean;

public class Wallet {

	private int accountno;
	private String type;
	private Double balance;
	private int customerid;
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	@Override
	public String toString() {
		return "Wallet [accountno=" + accountno + ", type=" + type + ", balance=" + balance + ", customerid="
				+ customerid + "]";
	}
	
}
