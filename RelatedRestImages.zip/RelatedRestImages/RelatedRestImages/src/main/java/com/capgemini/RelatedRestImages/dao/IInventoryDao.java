package com.capgemini.RelatedRestImages.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.RelatedRestImages.model.Inventory;

@Repository("inventoryDao")
public interface IInventoryDao extends JpaRepository<Inventory, Integer>{

}
