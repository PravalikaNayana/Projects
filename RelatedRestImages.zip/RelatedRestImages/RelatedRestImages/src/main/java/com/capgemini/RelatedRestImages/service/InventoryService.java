package com.capgemini.RelatedRestImages.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RelatedRestImages.dao.IInventoryDao;
import com.capgemini.RelatedRestImages.model.Inventory;

@Service("inventoryService")
@Transactional
public class InventoryService implements IInventoryService {

	@Autowired
	private IInventoryDao inventoryDao;
	
	@Override
	public List<Inventory> getAll() {
		
		return inventoryDao.findAll();
	}

}
