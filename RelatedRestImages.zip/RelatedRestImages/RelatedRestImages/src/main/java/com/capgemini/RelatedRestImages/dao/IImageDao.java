package com.capgemini.RelatedRestImages.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.RelatedRestImages.model.Inventory;
import com.capgemini.RelatedRestImages.model.ProductImages;

@Repository("imageDao")
public interface IImageDao extends JpaRepository<ProductImages, Integer>{

	@Query("select max(imageId) from ProductImages")
	public Integer findMaxImageId();
	
}
