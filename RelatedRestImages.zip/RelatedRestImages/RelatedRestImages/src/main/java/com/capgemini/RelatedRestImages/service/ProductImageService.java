package com.capgemini.RelatedRestImages.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RelatedRestImages.dao.IImageDao;
import com.capgemini.RelatedRestImages.model.Inventory;
import com.capgemini.RelatedRestImages.model.ProductImages;

@Service("imageService")
@Transactional
public class ProductImageService implements IProductImageService{

	@Autowired
	private IImageDao imageDao;

	@Override
	public List<ProductImages> getAll() {
		
		return imageDao.findAll();
	}

	@Override
	public void save(ProductImages product) {
		
		imageDao.save(product);
	}

	@Override
	public Integer findMaxImageId() {
		
		return imageDao.findMaxImageId();
		
	}

	@Override
	public ProductImages getById(Integer productId) {
		
		return imageDao.getOne(productId);
	}
/*
	@Override
	public List<ProductImages> getAllProducts() {
		// TODO Auto-generated method stub
		return imageDao.findAll();
	}*/
	
	/*@Override
	public List<ProductImage> findAll() {
		
		return null;
	}*/
	
	
}
