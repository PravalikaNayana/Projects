package com.capgemini.RelatedRestImages.service;

import java.util.List;

import com.capgemini.RelatedRestImages.model.Inventory;
import com.capgemini.RelatedRestImages.model.ProductImages;

public interface IProductImageService {

	public List<ProductImages> getAll();

	public void save(ProductImages product);

	public Integer findMaxImageId();

	public ProductImages getById(Integer productId);

	//public List<ProductImage> findAll();
	
	
	
}
