package com.capgemini.RelatedRestImages.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

//import com.capgemini.RelatedImages.service.IImageService;
//import com.capgemini.RelatedImages.service.IInventoryService;
import com.capgemini.RelatedRestImages.model.Inventory;
import com.capgemini.RelatedRestImages.model.ProductImages;
import com.capgemini.RelatedRestImages.service.IProductImageService;
import com.capgemini.RelatedRestImages.service.IInventoryService;

//import com.capgemini.RelatedFrontImages.model.Inventory;

@RestController
public class BackController {

	@Autowired
	private IProductImageService imageService;
	
	@Autowired
	private IInventoryService inventoryService;
	
	
	@RequestMapping("/")
	public ResponseEntity<List<Inventory>> uploadImagePage(ModelMap map)
	{
    	
    	List<Inventory> products=inventoryService.getAll();
		//map.put("products", products);
		System.out.println("Sharath");
		return new ResponseEntity<List<Inventory>>(products,HttpStatus.OK);
	}
	
	@GetMapping("/maxId")
	public Integer getMaxId()
	{
		System.out.println("id : controller");
	  int i=imageService.findMaxImageId();
	  System.out.println("i is"+i);
	  
		return i;
	}
	
	@PostMapping("/put1")
	public void putImage(@RequestBody ProductImages productimages)
	{
		System.out.println("Put : controller");
		imageService.save(productimages);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<ProductImages>> getAllImages(){
		System.out.println("getall : controller");
		
		List<ProductImages> images= imageService.getAll();
		if(images.isEmpty()||images==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ProductImages>>(images,HttpStatus.OK);
	}
	
	
}
