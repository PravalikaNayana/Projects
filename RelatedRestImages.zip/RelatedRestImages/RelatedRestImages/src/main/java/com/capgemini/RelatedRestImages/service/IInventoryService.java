package com.capgemini.RelatedRestImages.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.RelatedRestImages.model.Inventory;


public interface IInventoryService {

	public List<Inventory> getAll();

}
