package transactionProcessing;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {

	@Given("^customer is in payment page and gives valid payment details$")
	public void customer_is_in_payment_page_and_gives_valid_payment_details() throws Throwable {
	    
	}

	@When("^customer commits payment$")
	public void customer_commits_payment() throws Throwable {
	   
	}

	@Then("^money should be deducted and added to CapStore revenue$")
	public void money_should_be_deducted_and_added_to_CapStore_revenue() throws Throwable {
	   
	}

	@Then("^redirect to success page$")
	public void redirect_to_success_page() throws Throwable {
	   
	}

	@Given("^Admin is in get capStore revenue page$")
	public void admin_is_in_get_capStore_revenue_page() throws Throwable {
	   
	}

	@When("^Admin gives valid from date and till date$")
	public void admin_gives_valid_from_date_and_till_date() throws Throwable {
	   
	}

	@Then("^display capStore revenue$")
	public void display_capStore_revenue() throws Throwable {
	  
	}

	@When("^Admin gives future dates for from date and till date$")
	public void admin_gives_future_dates_for_from_date_and_till_date() throws Throwable {
	    
	}

	@When("^from date is greater than till date$")
	public void from_date_is_greater_than_till_date() throws Throwable {
	    
	}

	@Then("^display error message$")
	public void display_error_message() throws Throwable {
	    
	}


	
}
