package com.cg.CapStore.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.CapStore.service.IRevenueService;

@Controller
public class RevenueController {

	@Autowired
	private IRevenueService revenueService;
	
	@RequestMapping("/displayRevenue")
	public void getRevenue(@RequestParam("fromDate") Date fromDate,
			@RequestParam("tillDate") Date tillDate)
	{
		revenueService.getRevenue(fromDate,tillDate);
	}
	
}
