package com.cg.CapStore.service;

import java.util.Date;

public interface IRevenueService {

	public void getRevenue(Date fromDate,Date tillDate);
}
