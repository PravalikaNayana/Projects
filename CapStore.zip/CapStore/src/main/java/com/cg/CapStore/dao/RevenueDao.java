package com.cg.CapStore.dao;

public class RevenueDao implements IRevenueDao{

}
