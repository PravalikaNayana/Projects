package com.cg.CapStore.service;

public interface IPaymentService {

}
