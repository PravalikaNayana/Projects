package com.cg.CapStore.dao;

import org.springframework.stereotype.Repository;

@Repository("paymentDao")
public class PaymentDao implements IPaymentDao {

	
	
}
