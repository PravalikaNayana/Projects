package com.cg.CapStore.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class CapStoreTransaction {

	@Id
	private int transId;
	private Order order;
	private double amount;
	private String modeOfPurchase;
	private String statusOfTrans;
	private Date transactionDate;
	
	public CapStoreTransaction()
	{
		
	}
	
	public CapStoreTransaction(int transId, Order order, double amount, String modeOfPurchase, String statusOfTrans,
			Date transactionDate) {
		super();
		this.transId = transId;
		this.order = order;
		this.amount = amount;
		this.modeOfPurchase = modeOfPurchase;
		this.statusOfTrans = statusOfTrans;
		this.transactionDate = transactionDate;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getModeOfPurchase() {
		return modeOfPurchase;
	}
	public void setModeOfPurchase(String modeOfPurchase) {
		this.modeOfPurchase = modeOfPurchase;
	}
	public String getStatusOfTrans() {
		return statusOfTrans;
	}
	public void setStatusOfTrans(String statusOfTrans) {
		this.statusOfTrans = statusOfTrans;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	
}
