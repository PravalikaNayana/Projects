package com.cg.CapStore.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CapStoreTransaction {

	@Id
	private int transId;
	private Order order;
	private double amount;
	private String modeOfPurchase;
	private String statusOfTrans;
	
	public CapStoreTransaction(int transId, Order order, double amount, String modeOfPurchase, String statusOfTrans) {
		super();
		this.transId = transId;
		this.order = order;
		this.amount = amount;
		this.modeOfPurchase = modeOfPurchase;
		this.statusOfTrans = statusOfTrans;
	}
	
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getModeOfPurchase() {
		return modeOfPurchase;
	}
	public void setModeOfPurchase(String modeOfPurchase) {
		this.modeOfPurchase = modeOfPurchase;
	}
	public String getStatusOfTrans() {
		return statusOfTrans;
	}
	public void setStatusOfTrans(String statusOfTrans) {
		this.statusOfTrans = statusOfTrans;
	}
	
	
}
