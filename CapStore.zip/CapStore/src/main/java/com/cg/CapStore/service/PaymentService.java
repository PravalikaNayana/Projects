package com.cg.CapStore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("paymentService")
public class PaymentService implements IPaymentService{

	@Autowired
	private IPaymentService paymentService;
	
	
}
