package com.cg.CapStore.dao;

public interface IPaymentDao {

}
