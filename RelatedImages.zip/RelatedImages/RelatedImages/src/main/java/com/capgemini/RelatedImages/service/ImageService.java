package com.capgemini.RelatedImages.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RelatedImages.dao.IImageDao;
import com.capgemini.RelatedImages.model.Inventory;
import com.capgemini.RelatedImages.model.ProductImage;

@Service("imageService")
@Transactional
public class ImageService implements IImageService{

	@Autowired
	private IImageDao imageDao;

	@Override
	public List<ProductImage> getAll() {
		
		return imageDao.findAll();
	}

	@Override
	public void save(ProductImage product) {
		
		imageDao.save(product);
	}

	@Override
	public Integer findMaxImageId() {
		
		return imageDao.findMaxImageId();
		
	}

	@Override
	public ProductImage getById(Integer productId) {
		
		return imageDao.getOne(productId);
	}

	/*@Override
	public List<ProductImage> findAll() {
		
		return null;
	}*/
	
	
}
