package com.capgemini.RelatedImages.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Inventory {

	@Id
	private int productId;
	private String productName;
	
	public Inventory()
	{
		
	}
	
	public int getProductId() {
		return productId;
	}
	
	public Inventory(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
}
