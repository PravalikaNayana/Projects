package com.capgemini.RelatedImages.service;

import java.util.List;

import com.capgemini.RelatedImages.model.Inventory;
import com.capgemini.RelatedImages.model.ProductImage;

public interface IImageService {

	public List<ProductImage> getAll();

	public void save(ProductImage product);

	public Integer findMaxImageId();

	public ProductImage getById(Integer productId);

	//public List<ProductImage> findAll();
	
	
	
}
