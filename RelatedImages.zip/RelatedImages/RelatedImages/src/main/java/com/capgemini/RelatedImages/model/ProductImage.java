package com.capgemini.RelatedImages.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ProductImage {
	@Id
	@GeneratedValue
	private int imageId;
	private int productId;
	private String imgUrl;
	private boolean priority;
	public ProductImage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductImage(int imageId, int productId, String imgUrl, boolean priority) {
		super();
		this.imageId = imageId;
		this.productId = productId;
		this.imgUrl = imgUrl;
		this.priority = priority;
	}
	public int getImageId() {
		return imageId;
	}
	public void setImageId(int imageId) {
		this.imageId = imageId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public boolean isPriority() {
		return priority;
	}
	public void setPriority(boolean priority) {
		this.priority = priority;
	}
	@Override
	public String toString() {
		return "ProductImage [imageId=" + imageId + ", productId=" + productId + ", imgUrl=" + imgUrl + ", priority="
				+ priority + "]";
	}
	
}
