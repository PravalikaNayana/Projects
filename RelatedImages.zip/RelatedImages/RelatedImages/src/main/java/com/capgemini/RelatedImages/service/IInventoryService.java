package com.capgemini.RelatedImages.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.RelatedImages.model.Inventory;


public interface IInventoryService {

	public List<Inventory> getAll();

}
