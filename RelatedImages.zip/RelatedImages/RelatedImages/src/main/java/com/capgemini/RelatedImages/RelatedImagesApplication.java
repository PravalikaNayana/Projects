package com.capgemini.RelatedImages;

import java.io.File;
import java.io.IOException;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.capgemini.RelatedImages.controller.MyController;

@SpringBootApplication
public class RelatedImagesApplication {

	public static void main(String[] args)throws IOException {
		new File(MyController.uploadingdir).mkdirs();
		new File(MyController.productname).mkdirs();
		new File(MyController.productid).mkdirs();
		new File(MyController.imageid).mkdirs();
		SpringApplication.run(RelatedImagesApplication.class, args);
	}
}
