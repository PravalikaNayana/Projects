package com.capgemini.RelatedImages.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.RelatedImages.model.Inventory;
import com.capgemini.RelatedImages.model.ProductImage;

@Repository("imageDao")
public interface IImageDao extends JpaRepository<ProductImage, Integer>{

	@Query("select max(imageId) from ProductImage")
	public Integer findMaxImageId();
	
}
