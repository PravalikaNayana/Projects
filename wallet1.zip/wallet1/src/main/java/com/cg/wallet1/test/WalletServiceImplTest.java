package com.cg.wallet1.test;

import com.cg.wallet1.bean.Wallet;
import com.cg.wallet1.exception.WalletException;
import com.cg.wallet1.service.WalletServiceImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

public class WalletServiceImplTest extends TestCase {


	public void testValidateName() throws WalletException{

		WalletServiceImpl w=new WalletServiceImpl();
		Assert.assertEquals(true, w.validateName("Dhoni"));
		
	}

	public void testValidatePhone() throws WalletException{
		WalletServiceImpl w=new WalletServiceImpl();
		Assert.assertEquals(true, w.validatePhone("8712987456"));

		
	}

	public void testCreateAccount() {
		
		WalletServiceImpl w=new WalletServiceImpl();
		Wallet a=new Wallet();
		Assert.assertEquals(5001, 5001);
		
	}

	public void testValidateNameFail() {

		WalletServiceImpl c=new WalletServiceImpl();
		
		try {
			Assert.assertEquals(false, c.validateName("pravalika@"));
		}
		catch(WalletException e){
			
		}
	}

	public void testValidatePhoneFail() {
		
		WalletServiceImpl w=new WalletServiceImpl();
		try {
			Assert.assertEquals(false, w.validatePhone("809876543213"));
		}
		catch(WalletException ex)
		{
			
		}
		
	}

	

}
