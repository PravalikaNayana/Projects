package com.cg.wallet1.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.wallet1.bean.Customer;
import com.cg.wallet1.bean.Transactions;
import com.cg.wallet1.bean.Wallet;
import com.cg.wallet1.exception.WalletException;

public class WalletDaoImpl implements WalletDao{

	
	static HashMap<Integer,Customer> custmap=new HashMap<Integer,Customer>();
	static HashMap<Integer,Wallet> walletmap=new HashMap<Integer,Wallet>();
	static Map<String,Transactions> transactions=new HashMap<String,Transactions>();
	static Transactions transaction=new Transactions();
	
	public int createAccount(Customer customer) throws WalletException {

	try {
			if(custmap.size()==0)
			{
				customer.setId(1001);
			}
			else {
				Optional<Integer> id=custmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int custid=id.get()+1;
				customer.setId(custid);
			}
			custmap.put(customer.getId(), customer);
			return customer.getId();
			
		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	public int assignAccount(String type) throws WalletException {
		Wallet wallet=new Wallet();
		double balanceamount=0;

		try {
			if(walletmap.size()==0)
			{
				wallet.setAccountno(5001);
				wallet.setBalance(balanceamount);
			}
			else {
				Optional <Integer> account=walletmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int accno=account.get()+1;
				wallet.setAccountno(accno);
				wallet.setBalance(balanceamount);
			}

			walletmap.put(wallet.getAccountno(), wallet);

		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
		return wallet.getAccountno();
	}

	public double showBalance(int accno) throws WalletException {

		Wallet value=new Wallet();
		double balance=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					balance=value.getBalance();
				}
		}
		catch(Exception ex)
		{
			System.err.println("Error occured:"+ex.getMessage());
		}
		return balance;
	}

	@Override
	public double deposit(int accno, double amount) throws WalletException {

		Wallet value=new Wallet();
		double famount=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()+amount;
					value.setBalance(famount);
					String accnostr=String.valueOf(accno);
					Transactions transaction=new Transactions();
					transaction.setAccno(accnostr);
					transaction.setTransactiontype("Deposit");
					transaction.setAmount(amount);
					transaction.setBalance(famount);
					transactions.put(accnostr, transaction);
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return famount;
	}

	public int withdraw(int accno, double amount) throws WalletException {
		Wallet value=new Wallet();
		double famount=0;
		int status=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()-amount;
					value.setBalance(famount);
					status=1;
					String accnostr=String.valueOf(accno);
					Transactions transaction=new Transactions();

					transaction.setAccno(accnostr);
					transaction.setTransactiontype("Withdraw:");
					transaction.setAmount(amount);
					transaction.setBalance(famount);
					transactions.put(accnostr, transaction);
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	}

	public int fundTransfer(int faccno, int taccno, double amount) throws WalletException {
		
		Wallet value1=new Wallet();	
		Wallet value2=new Wallet();

		
		double fromfinalamount=0;
		double tofinalamount=0;
		int status=0;
	
		try {
			if(!walletmap.containsKey(faccno)&&!walletmap.containsKey(taccno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value1=walletmap.get(faccno);
					value2=walletmap.get(taccno);

					fromfinalamount=value1.getBalance()-amount;
					tofinalamount=value2.getBalance()+amount;
					
					value1.setBalance(fromfinalamount);
					value2.setBalance(tofinalamount);
					
					String faccnoStr=String.valueOf(faccno);
					
					Transactions transaction1=new Transactions();
					transaction1.setAccno(faccnoStr);
					transaction1.setTransactiontype("Debited");
					transaction1.setAmount(amount);
					transaction1.setBalance(fromfinalamount);
					transactions.put(faccnoStr, transaction1);

					String taccnoStr=String.valueOf(taccno);

					Transactions transaction2=new Transactions();
					transaction2.setAccno(taccnoStr);
					transaction2.setTransactiontype("Credited");
					transaction2.setAmount(amount);
					transaction2.setBalance(tofinalamount);
					transactions.put(taccnoStr, transaction2);
					
					status=1;
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	
	}

	@Override
	public Transactions printTransactions(String accno) throws WalletException {

		
		try {
			
			Map<String,Transactions> transactionmap=new HashMap<String,Transactions>();
			Transactions transaction=transactions.get(accno);
			if(transaction==null)
			{
				throw new WalletException("Customer with the Account number"+accno+" not available");
			}
			/*else
			{
				Iterator<Transactions> iter=transactions.iterator();
				while(iter.hasNext())
				{	
				}
				System.out.println(transaction);
			}*/
			return transaction;

		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
		
	}

	

	
	
}
