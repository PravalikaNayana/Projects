package com.cg.capstore.model;

import java.util.Date;
import java.util.List;





public class Customer {

	
	private int customerId;
	private String customerName;
	private String phoneNumber;
	private String emailId;
	private Date dateOfBirth;
	private String password;
	//private List<Address> address;
	private Date lastLogin;
	private String isActive;
	//private Shipping shipping;

	//private List<BankAccount> bank;
	//private List<ManagingCart> managingCart;
	//private List<Order> order;
	
	//private List<FeedBack> feedBack;
	
	//private List<ReturnOrders> returnOrders; 

	//private List<WishList> wishList;
	
	public Customer() {
		
	}
	
	

	public Customer(int customerId, String customerName, String phoneNumber, String emailId, Date dateOfBirth,
			String password, Date lastLogin, String isActive) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
		this.lastLogin = lastLogin;
		this.isActive = isActive;
	}



	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	


	
	
	

}
