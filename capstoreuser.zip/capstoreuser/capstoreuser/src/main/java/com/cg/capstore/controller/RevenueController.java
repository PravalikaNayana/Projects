package com.cg.capstore.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class RevenueController {

	double amount;
	
	@RequestMapping("/revenue")
	public String showPage(ModelMap map)
	{
		System.out.println("NAYANA!!");
		/*final String uri="http://localhost:8087/CapStoreRest/api/v1/displayRevenue";
		RestTemplate restTemplate=new RestTemplate();*/
		if(amount==0) {
			map.put("amount", null);
		}
		else{
			map.put("amount", amount);
		}
		return "revenuePage";
	}
	
	@RequestMapping("/displayRevenue")
	public String getRevenue(@RequestParam("fromDate") Date fromDate,
			@RequestParam("tillDate") Date tillDate)
	{
		final String uri="http://localhost:8087/capStore/api/v1/displayRevenue/";
		RestTemplate restTemplate=new RestTemplate();
		 
		//restTemplate.
		return "revenuePage";
		
	}
	
}
