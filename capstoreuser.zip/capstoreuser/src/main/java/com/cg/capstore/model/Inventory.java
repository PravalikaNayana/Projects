package com.cg.capstore.model;

import java.util.Date;
import java.util.List;




public class Inventory {
	private int productId;
	private String productName;
	private String description;
	
	//private Brand brand;
	
	//private Merchant merchant;
	
	private int noOfViews;
	private String Category;
	private Date dateOfInclusion;
	private double price;
	
	//private List<ProductImages> uploadimage;
	
	private int quantity;
	private Date expiryDate;
	//private ManagingCart managingCart;
	
	//private Discount discount;
	
	//private Coupons coupon;
	
	//private List<FeedBack> feedback;
	
	//private WishList wishList;
	
	public Inventory() {
		
	}
	
	
	
	public Inventory(int productId, String productName, String description, int noOfViews, String category,
			Date dateOfInclusion, double price, int quantity, Date expiryDate) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.noOfViews = noOfViews;
		Category = category;
		this.dateOfInclusion = dateOfInclusion;
		this.price = price;
		this.quantity = quantity;
		this.expiryDate = expiryDate;
	}



	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getNoOfViews() {
		return noOfViews;
	}
	public void setNoOfViews(int noOfViews) {
		this.noOfViews = noOfViews;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public Date getDateOfInclusion() {
		return dateOfInclusion;
	}
	public void setDateOfInclusion(Date dateOfInclusion) {
		this.dateOfInclusion = dateOfInclusion;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
		
	
}
