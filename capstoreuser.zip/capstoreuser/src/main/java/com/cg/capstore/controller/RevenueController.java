package com.cg.capstore.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;



@Controller
public class RevenueController {

	@RequestMapping("/revenue")
	public String showPage()
	{
		System.out.println("NAYANA!!");
		/*final String uri="http://localhost:8087/CapStoreRest/api/v1/displayRevenue";
		RestTemplate restTemplate=new RestTemplate();*/
		return "revenuePage";
	}
	
	@RequestMapping("/displayRevenue")
	public String getRevenue(@RequestParam("fromDate") Date fromDate,
			@RequestParam("tillDate") Date tillDate)
	{
		final String uri="http://localhost:8087/CapStoreRest/api/v1/displayRevenue";
		RestTemplate restTemplate=new RestTemplate();
		 
		//restTemplate.
		return "revenuePage";

	}
	
}
