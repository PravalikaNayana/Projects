package com.cg.capstore.model;

import java.util.Date;
import java.util.List;




public class Order{
	
	
	private int orderId;
	
	private Customer customer;
	
	//private  List<ManagingCart> managingCart;
	
	private Date orderDate;
	private Date deliveredDate;
	
	//private Shipping shipping;
	
	private String deliveryStatus;
	
	private CapStoreTransaction transaction;
	
	//private ReturnOrders returnOrder;
	

	public Order() {
		super();
	}
	
	
	
	public Order(int orderId, Customer customer, Date orderDate, Date deliveredDate, String deliveryStatus,
			CapStoreTransaction transaction) {
		super();
		this.orderId = orderId;
		this.customer = customer;
		this.orderDate = orderDate;
		this.deliveredDate = deliveredDate;
		this.deliveryStatus = deliveryStatus;
		this.transaction = transaction;
	}



	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Date getDeliveredDate() {
		return deliveredDate;
	}
	public void setDeliveredDate(Date deliveredDate) {
		this.deliveredDate = deliveredDate;
	}
	
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public CapStoreTransaction getTransaction() {
		return transaction;
	}
	public void setTransaction(CapStoreTransaction transaction) {
		this.transaction = transaction;
	}
	

}
