package Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageBean {
	WebDriver driver;
	@FindBy(name="name")
	private WebElement name;
	@FindBy(name="cardNo")
	private WebElement cardNo;
	@FindBy(name="cvvNo")
	private WebElement cvvNo;
	@FindBy(name="exDate")
	private WebElement exDate;
	@FindBy(name="payment")
	private WebElement payment;
	public PaymentPageBean(WebDriver driver) {
		 this.driver=driver;
		 PageFactory.initElements(driver, this);
	}
	public void setName(String hname)
	{
		name.sendKeys(hname);
	}
	public void setCardNo(String cno)
	{
		cardNo.sendKeys(cno);
	}
	public void setCVVNo(String cvvno)
	{
		cvvNo.sendKeys(cvvno);
	}
	public void setExDate(String edate)
	{
		exDate.sendKeys(edate);
	}
	public void setPayment()
	{
		payment.submit();
	}
	public void Payment_succesfull(String name,String cardNo,String cvvNo,String exDate) {
		 this.setName(name);
		 this.setCardNo(cardNo);
		 this.setCVVNo(cvvNo);
		 this.setExDate(exDate);
		 this.setPayment();
	}

}
