package Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StudentPageBean {
WebDriver driver;
@FindBy(name="firstName")
private WebElement firstName;
@FindBy(name="lastName")
private WebElement lastName;
@FindBy(name="address")
private WebElement address;
@FindBy(name="city")
private WebElement city;
@FindBy(name="state")
private WebElement state;
@FindBy(name="gender")
private WebElement gender;
@FindBy(name="course")
private WebElement course;
@FindBy(name="mobilenum")
private WebElement mobilenum;
@FindBy(name="submit")
private WebElement submit;

public StudentPageBean(WebDriver driver) {
	 this.driver=driver;
	 PageFactory.initElements(driver, this);
}

public void setFirstName(String fname)
{
	firstName.sendKeys(fname);
}

public void setLastName(String lname)
{
	lastName.sendKeys(lname);
}

public void setAddress(String addr)
{
	address.sendKeys(addr);
}

public void setCity(String cty)
{
	city.sendKeys(cty);
}

public void setState(String st)
{
	state.sendKeys(st);
}

public void setGender(String gen)
{
	gender.sendKeys(gen);
}

public void setCourse(String crs)
{
	course.sendKeys(crs);
}

public void setMobileNum(String mobile)
{
	mobilenum.sendKeys(mobile);
}

public void setSubmit()
{
	submit.submit();
}
public void loginTo_NextPage(String firstName,String lastName,String address,String city,String state,String gender,String course,String mobilenum) {
	 this.setFirstName(firstName);
	 this.setLastName(lastName);
	 this.setAddress(address);
	 this.setCity(city);
	 this.setState(state);
	 this.setGender(gender);
	 this.setCourse(course);
	 this.setMobileNum(mobilenum);
	 this.setSubmit();
}
}





