package com.capgemini.RelatedFrontImages.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.RelatedFrontImages.model.Inventory;
import com.capgemini.RelatedFrontImages.model.ProductImages;

@Controller
public class FrontController {

	public static final String uploadingdir = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/";
    public static final String productname = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/productname";
    public static final String productid = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/productname/productid";
    public static final String imageid = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/productname/productid/imageid/";
    
    
    @RequestMapping("/")
	public String uploadImagePage(ModelMap map)
	{
    	final String uri="http://localhost:8055/imageRest/api/v1/getProducts";
		RestTemplate restTemplate=new RestTemplate();
    	//List<Inventory> products=inventoryService.getAll();
		
		Inventory[] products=restTemplate.getForObject(uri, Inventory[].class);
		map.put("products", products);
		System.out.println("Sharath");
		return "relatedImage";
	}
    //public static final String uploadingdir = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/";
	 
	 /*@RequestMapping("/")
	    public String uploading(Model model) {
	        File file = new File(uploadingdir);
	        model.addAttribute("files", file.listFiles());
	        model.addAttribute("productimages", new ProductImages());
	        return "uploading";
	    }*/
	 
	 @RequestMapping(value = "/upload", method = RequestMethod.POST)
	    public String uploadingPost(@RequestParam("uploadingFiles") MultipartFile uploadingFiles,
	    		@ModelAttribute("product") ProductImages productimages) throws IOException {
	    	int imgName=0;
	            File file = new File(uploadingdir + uploadingFiles.getOriginalFilename());
	            uploadingFiles.transferTo(file);
	          
	            String path=file.getPath();
	            
	           String extenstion= path.substring(path.lastIndexOf('.'), path.length());
	            
	            System.out.println(extenstion);
	            
	            final String uri="http://localhost:8055/imageRest/api/v1/maxId";
				RestTemplate restTemplate=new RestTemplate();
				
				Integer imageId=(Integer)restTemplate.getForObject(uri, Integer.class);
	            
	            System.out.println("hii");
	           
	           if(imageId!=null)
	            	imgName=imageId+1;
	            else
	            	imgName=0;
	            File file2=new File(uploadingdir+imgName+ extenstion);
	            file.renameTo(file2);
	            
	            
	            productimages.setUrl("../uploadingdir/" +imgName+ extenstion);
	            
	            
	        	final String uri1="http://localhost:8055/imageRest/api/v1/put1";
				RestTemplate restTemplate1=new RestTemplate();
				
		
				restTemplate1.postForEntity(uri1,productimages,ProductImages.class);
	    
	        return "redirect:show";
	    }
	    
	    
	    @RequestMapping("/show")
	    public String showProducts(Model model) {
	    	
	    	 final String uri="http://localhost:8055/imageRest/api/v1/getAll";
				RestTemplate restTemplate=new RestTemplate();
				
				ProductImages[] images=
						restTemplate.getForObject(uri,ProductImages[].class);
			System.out.println("HELLO!!");
	    	model.addAttribute("images", images);
	    	return "show";
	    }
	 
    
}
