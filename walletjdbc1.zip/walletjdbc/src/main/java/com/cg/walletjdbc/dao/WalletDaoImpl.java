package com.cg.walletjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.bean.Transactions;
import com.cg.walletjdbc.bean.Wallet;
import com.cg.walletjdbc.exception.WalletException;
import com.cg.walletjdbc.util.DBConnection;

public class WalletDaoImpl implements WalletDao{

	Logger logger=Logger.getRootLogger();

	public WalletDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	@Override
	public int createAccount(Customer customer) throws WalletException {

		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int customerId=0;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,customer.getName());
			preparedStatement.setInt(2,customer.getAge());
			preparedStatement.setString(3,customer.getGender());
			preparedStatement.setString(4,customer.getPhone());
			preparedStatement.setString(5,customer.getAddress());

					
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMERID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				customerId=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return customerId;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}

	@Override
	public int assignAccount(String type,double initbalance) throws WalletException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int accno=1001;
		
		int queryResult=0;
		
		Wallet wallet=new Wallet();
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_INTO_WALLET);

			preparedStatement.setString(1,type);
			preparedStatement.setDouble(2,initbalance);
					
			queryResult=preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.SELECT_FROM_WALLET);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				accno=resultSet.getInt(1);
						
			}

			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Your account has been created successfully..!");
				return accno;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}

	@Override
	public double showBalance(int accno) throws WalletException {

		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		int queryResult=0;
		double balance=0;
		Wallet wallet=new Wallet();
		try
		{		
/*			wallet.setAccountno(accno);
*/			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_ACCBAL_FROM_WALLET);
			preparedStatement.setInt(1, accno);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				balance=resultSet.getDouble(1);

				logger.info("Your account balance is:");
				return balance;
			}
	
			else
			{
				throw new WalletException("Problem in retrieving the balance!");
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}

	@Override
	public double deposit(int accno, double amount) throws WalletException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
/*		Statement statement=null;
*/		
		ResultSet resultSet = null;
		int queryResult=0;
		int queryResult1=0;

		double balance=0;
		Wallet wallet=new Wallet();
		try
		{		

/*			wallet.setAccountno(accno);
*/			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_ACCBAL_FROM_WALLET);

			preparedStatement.setInt(1, accno);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				balance=resultSet.getDouble(1)+amount;
/*				wallet.setBalance(balance);
*/				/*statement=connection.createStatement();
				queryResult=statement.executeUpdate(QueryMapper.UPDATE_ACCBAL);*/
				preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_ACCBAL);
				preparedStatement.setDouble(1, balance);
				preparedStatement.setInt(2, accno);
				queryResult=preparedStatement.executeUpdate();
				
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTIONS);
				String transactiontype="Deposited";
				preparedStatement.setInt(1,accno);
				preparedStatement.setInt(2,accno);
				preparedStatement.setString(3,transactiontype);
				preparedStatement.setDouble(4,amount);
				preparedStatement.setDouble(5,balance);
				queryResult1=preparedStatement.executeUpdate();

			}
			
			if(queryResult!=0)
			{
				logger.info("Amount has been deposited successfully..!");
				logger.info("Your current account balance is:");
				return balance;
			}
			else
			{
				throw new WalletException("Problem in updating the balance!");
			}

			
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	
	}

	@Override
	public double withdraw(int accno, double amount) throws WalletException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
/*		Statement statement=null;
*/		
		ResultSet resultSet = null;
		int queryResult=0;
		double balance=0;
		Wallet wallet=new Wallet();
		try
		{		
/*			wallet.setAccountno(accno);
*/			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_ACCBAL_FROM_WALLET);
			preparedStatement.setInt(1,accno);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				balance=resultSet.getDouble(1)-amount;
				preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_ACCBAL);
				preparedStatement.setDouble(1, balance);
				preparedStatement.setInt(2, accno);
				queryResult=preparedStatement.executeUpdate();
				
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTIONS);
				String transactiontype="Withdrawn";
				preparedStatement.setInt(1,accno);
				preparedStatement.setInt(2,accno);
				preparedStatement.setString(3,transactiontype);
				preparedStatement.setDouble(4,amount);
				preparedStatement.setDouble(5,balance);
				int queryResult1 = preparedStatement.executeUpdate();

			}
			
			if(queryResult!=0)
			{
				logger.info("Amount has been deposited successfully..!");
				logger.info("Your current account balance is:");
				return balance;
			}
			else
			{
				throw new WalletException("Problem in updating the balance!");
			}

			
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	
	}

	@Override
	public int fundTransfer(int faccno, int taccno, double amount) throws WalletException {

		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
/*		Statement statement=null;
*/		
		ResultSet resultSet1 = null;
		ResultSet resultSet2= null;

		ResultSet resultSet=null;
		int fqueryResult=0;
		int tqueryResult=0;
		
		int queryResult1=0;
		int queryResult2=0;
		int status=0;
		double fbalance=0;
		double tbalance=0;
		Wallet wallet=new Wallet();
		
		try
		{		
/*			wallet.setAccountno(faccno);
*/			
			
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_ACCBAL_FROM_WALLET);
			preparedStatement.setInt(1, faccno);
			resultSet1=preparedStatement.executeQuery();
			
			
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_ACCBAL_FROM_WALLET);
			preparedStatement.setInt(1, taccno);
			resultSet2=preparedStatement.executeQuery();

			if(resultSet1.next()&&resultSet2.next())
			{
				fbalance=resultSet1.getDouble(1)-amount;
				preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_ACCBAL);
				preparedStatement.setDouble(1, fbalance);
				preparedStatement.setInt(2, faccno);
				queryResult1=preparedStatement.executeUpdate();
				
				tbalance=resultSet2.getDouble(1)+amount;
				preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_ACCBAL);
				preparedStatement.setDouble(1, tbalance);
				preparedStatement.setInt(2, taccno);
				queryResult2=preparedStatement.executeUpdate();
				
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTIONS);
				String transactiontype="Credited";
				preparedStatement.setInt(1,faccno);
				preparedStatement.setInt(2,taccno);
				preparedStatement.setString(3,transactiontype);
				preparedStatement.setDouble(4,amount);
				preparedStatement.setDouble(5,fbalance);
				fqueryResult = preparedStatement.executeUpdate();
				
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_TRANSACTIONS);
				String transactiontype1="Debited";
				preparedStatement.setInt(1,taccno);
				preparedStatement.setInt(2,faccno);
				preparedStatement.setString(3,transactiontype1);
				preparedStatement.setDouble(4,amount);
				preparedStatement.setDouble(5,tbalance);
				tqueryResult = preparedStatement.executeUpdate();

			}
			if(queryResult1!=0&&queryResult2!=0&&fqueryResult!=0&&tqueryResult!=0)
			{
				status=1;
				logger.info("Amount has been transfered successfully..!");
				return status;
			}
			else
			{
				throw new WalletException("Problem in transfering the amount!");
			}

			
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}

	@Override
	public ResultSet printTransactions(int accno) throws WalletException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		int queryResult=0;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_TRANSACTIONS);
			preparedStatement.setInt(1,accno);
			resultSet=preparedStatement.executeQuery();
			
			System.out.println("Transaction-id    From account    To account    Transaction type       Amount       Balance");
			while(resultSet.next())
			{
				System.out.println("   "+resultSet.getInt(1)+"                "+resultSet.getInt(2)+"              "+resultSet.getInt(3)+"            "+resultSet.getString(4)+"           "+resultSet.getDouble(5)+"         "+resultSet.getDouble(6));
			}

			return resultSet;
			
		}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}

	
	
}
